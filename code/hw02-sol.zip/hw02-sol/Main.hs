{-# OPTIONS -fwarn-incomplete-patterns -fwarn-tabs -fno-warn-type-defaults #-}

{-# OPTIONS -fdefer-type-errors  #-}

{-# LANGUAGE RankNTypes #-}

module Main where
import Prelude hiding (takeWhile, all, zip, reverse, concat)
import Test.HUnit
import qualified Data.List as List
import qualified Data.Char as Char
import qualified Data.Maybe as Maybe
import qualified Text.Read as Read

main :: IO ()
main = do
   _ <- runTestTT $ TestList [ testLists,
                               testWeather,
                               testSoccer ]
   return ()

----------------------------------------------------------

testLists :: Test
testLists = "testLists" ~: TestList
  [tintersperse, tinvert, ttranspose, tconcat, tcountSub]

-- The intersperse function takes an element and a list
-- and intersperses that element between the elements of the list.
-- For example,
--    intersperse ',' "abcde" == "a,b,c,d,e"
--
-- intersperse is defined in Data.List, and you can test your solution against
-- that one.

-- intersperse sep []     = []
-- intersperse sep [x]    = [x]
-- intersperse sep (x:xs) = x : sep : intersperse sep xs

-- a more general solution
prependToAll sep []     = []
prependToAll sep (x:xs) = sep : x : prependToAll sep xs

-- intersperse
intersperse sep []     = []
intersperse sep (x:xs) = x : prependToAll sep xs 

tintersperse :: Test
tintersperse = "intersperse" ~:
   TestList [ intersperse ',' [] ~?= [],
              intersperse ',' "a" ~?= "a",
              intersperse ',' "abcde" ~?= "a,b,c,d,e" ]              

-- invert
invert = map (\(x,y) -> (y,x)) 

tinvert :: Test
tinvert = "invert" ~:
   TestList [ invert [("a",1),("a",2)] ~?= [(1,"a"),(2,"a")],
              invert [("a",1),("a",2)] ~?= [(1,"a"),(2,"a")],
              invert ([] :: [(Int,Char)]) ~?= [] ]
 
-- concat :: [[a] -> [a]

-- The concatenation of all of the elements of a list of lists
-- for example:
--    concat [[1,2,3],[4,5,6],[7,8,9]] returns [1,2,3,4,5,6,7,8,9]
--
-- NOTE: remember you cannot use any functions from the Prelude or Data.List for
-- this problem, even for use as a helper function.

-- concat :: [[a] -> [a]
concat = foldr (++) []   -- not efficient

-- a more efficient solution, based on the concept of difference lists
-- that will be studied in a later lesson
-- note: build uses RankNTypes
build :: forall a. (forall b. (a -> b -> b) -> b -> b) -> [a]
build g = g (:) []

-- concat :: (Foldable t1, Foldable t2) => t1 (t2 a) -> [a]
-- concat xs = build (\c n -> foldr (\x y -> foldr c y x) n xs)

tconcat :: Test
tconcat = "concat" ~:
   TestList [ concat ([] :: [[Char]]) ~?= [],
              concat [[],"abcd"] ~?= "abcd",
              concat ["ab", "cde"] ~?= "abcde" ] 

-- transpose  (WARNING: this one is tricky!)

-- The transpose function transposes the rows and columns of its argument.
-- If the inner lists are not all the same length, then the extra elements
-- are ignored. Note, this is *not* the same behavior as the library version
-- of transpose.

-- for example:
--    transpose [[1,2,3],[4,5,6]] returns [[1,4],[2,5],[3,6]]
--    transpose  [[1,2],[3,4,5]] returns [[1,3],[2,4]]
--    transpose  [[]] returns []
-- transpose is defined in Data.List

-- transpose :: [[a]] -> [[a]] 
transpose               :: [[a]] -> [[a]]
transpose []             = []
transpose ([]     : xss) = transpose xss
transpose ((x:xs) : xss) = (x : [h | (h:_) <- xss]) : transpose (xs : [ t | (_:t) <- xss])

ttranspose :: Test
ttranspose = "transpose" ~:
  TestList [ transpose [[1,2,3],[4,5,6]] ~?= [[1,4],[2,5],[3,6]],
             transpose [[1,2],[3,4,5]] ~?= [[1,3],[2,4]],
             transpose ([[]] :: [[Int]]) ~?=  [],
             transpose ([]::[[Int]]) ~?= [],
             transpose [[1,2,3],[4,5],[6,7,8]] ~?= [[1,4,6],[2,5,7]] ]

-- countSub sub str

-- Return the number of (potentially overlapping) occurrences of substring sub
-- found in the string str.
-- for example:
--      countSub "aa" "aaa" returns 2

-- countSub :: [Char] -> [Char] -> Integr
countSub = countSub' 0
countSub' n sub [] = n
countSub' n sub xs
   | List.isPrefixOf sub xs = countSub' (n+1) sub (tail xs)
   | otherwise              = countSub' n sub (tail xs)
  
tcountSub :: Test
tcountSub = "countSub" ~:
   TestList [ countSub "aa" "aaa" ~?= 2,
              countSub "aa" "abaabaaa" ~?= 3,
              countSub "aa" "abab" ~?= 0,
              countSub "aa" "" ~?= 0 ]

--------------------------------------------------------------------------------

-- Part One: Hottest Day

-- / Applies a function to the value in a Maybe if the value exists
maybeMap :: (a -> b) -> Maybe a -> Maybe b
maybeMap _ Nothing  = Nothing
maybeMap f (Just x) = Just $ f x
-- / Applies a function to the value in two Maybes if both values exist
maybeMap2 :: (a -> b -> c) -> Maybe a -> Maybe b -> Maybe c
maybeMap2 f (Just x) (Just y) = Just $ f x y
maybeMap2 _ _        _        = Nothing

wProcessData :: Maybe (String,String,String) -> Maybe (Int, String)
wProcessData (Just (day,high,low)) =
   maybeMap (\x -> (x,day)) (maybeMap2 (\x y -> abs (x-y)) (readInt high) (readInt low))
wProcessData _ = Nothing

wExtractor :: [String] -> Maybe (String,String,String)
wExtractor (day:high:low:_) = Just (day,high,low)
wExtractor _                = Nothing

-- weather :: String -> String
weather str = ( dropWhile (==' ') .
                snd . 
                minimum .
                Maybe.catMaybes .
                map (wProcessData) .
                map wExtractor .
                map words .
                drop 18 .
                lines) str
 

weatherProgram :: IO ()
weatherProgram = do
  str <- readFile "jul17.dat"
  putStrLn (weather str)

readInt :: String -> Maybe Int
readInt = Read.readMaybe

testWeather :: Test
testWeather = "weather" ~: do str <- readFile "jul17.dat"
                              weather str @?= "6"

--------

-- Part Two: Soccer League Table
sExtractor :: [String] -> Maybe (String,String,String)
sExtractor (_:name:_:_:_:_:ptsFor:_:ptsAgainst:_) = Just (name, ptsFor, ptsAgainst)
sExtractor _                                      = Nothing

sProcessData :: Maybe (String,String,String) -> Maybe (Int, String)
sProcessData (Just (name,ptsFor,ptsAgainst)) =
   maybeMap (\x -> (x,name)) (maybeMap2 (\x y -> abs (x-y)) (readInt ptsFor) (readInt ptsAgainst))
sProcessData _ = Nothing

-- soccer :: String -> String
soccer str  = ( dropWhile (==' ') .
                snd . 
                minimum .
                Maybe.catMaybes .
                map (sProcessData) .
                map sExtractor .
                map words .
                drop 1 .
                lines) str

soccerProgram :: IO ()
soccerProgram = do
  str <- readFile "soccer.dat"
  putStrLn (soccer str)

testSoccer :: Test
testSoccer = "soccer" ~: do
  str <- readFile "soccer.dat"
  soccer str @?= "Aston_Villa"

-- Part Three: DRY Fusion
(|>) :: a -> (a -> b) -> b
(|>) = flip ($)

smallestDifference processData lineExtractor skipLines str =
    lines str
       |> drop skipLines
       |> map words
       |> map lineExtractor
       |> map (processData)
       |> Maybe.catMaybes
       |> minimum
       |> snd
       |> dropWhile (==' ')

weather2 :: String -> String
weather2 = smallestDifference wProcessData wExtractor 18

soccer2 :: String -> String
soccer2 = smallestDifference sProcessData sExtractor 1

-- Kata Questions
-- What are your answers to these questions? 

-- To what extent did the design decisions you made when writing the original
-- programs make it easier or harder to factor out common code?

-- Was the way you wrote the second program influenced by writing the first?

-- Is factoring out as much common code as possible always a good thing? Did the
-- readability of the programs suffer because of this requirement? How about the
-- maintainability?