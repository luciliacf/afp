{-# OPTIONS -fwarn-incomplete-patterns -fwarn-tabs -fno-warn-type-defaults #-}

-- {-# OPTIONS -fdefer-type-errors  #-}

module Main where
import Prelude hiding (takeWhile, all, concat)
import Test.HUnit      -- unit test support

import XMLTypes        -- support file for XML problem (provided)
import Play            -- support file for XML problem (provided)

doTests :: IO ()
doTests = do
  _ <- runTestTT $ TestList [ testHO, testFoldr, testTree, testFoldTree, testXML ]
  return ()

main :: IO ()
main = do
       doTests
       return ()

testHO :: Test
testHO = TestList [ttakeWhile, tfind, tall, tmap2, tmapMaybe]

-- takeWhile, applied to a predicate p and a list xs,
-- returns the longest prefix (possibly empty) of xs of elements
-- that satisfy p:
-- For example,
--     takeWhile (< 3) [1,2,3,4,1,2,3,4] == [1,2]
--     takeWhile (< 9) [1,2,3] == [1,2,3]
--     takeWhile (< 0) [1,2,3] == []

takeWhile :: (a -> Bool) -> [a] -> [a]
takeWhile p = foldr f []
   where f x xs
           | p x       = x : xs
           | otherwise = []

ttakeWhile :: Test
ttakeWhile = "takeWhile" ~: TestList
   [takeWhile (< 3) [1,2,3,4,1,2,3,4] ~?= [1,2],
    takeWhile (< 9) [1,2,3] ~?= [1,2,3],
    takeWhile (< 0) [1,2,3] ~?= [] ]
    
-- find pred lst returns the first element of the list that
-- satisfies the predicate. Because no element may do so, the
-- answer is returned in a "Maybe".
-- for example:
--     find odd [0,2,3,4] returns Just 3

find :: (a -> Bool) -> [a] -> Maybe a
find p [] = Nothing
find p (x:xs)
   | p x       = Just x
   | otherwise = find p xs 

tfind :: Test
tfind = "find" ~: TestList
   [ find odd [0,2,3,4] ~?= Just 3,
     find odd [2,4,6] ~?= Nothing ]
   
-- all pred lst returns False if any element of lst
-- fails to satisfy pred and True otherwise.
-- for example:
--    all odd [1,2,3] returns False

all  :: (a -> Bool) -> [a] -> Bool
all p = foldr (\x y -> p x && y) True

tall :: Test
tall = "all" ~: TestList
   [ all odd [1,2,3] ~?= False,
     all even [2,2,8] ~?= True,
     all odd [] ~?= True ]

-- map2 f xs ys returns the list obtained by applying f to
-- to each pair of corresponding elements of xs and ys. If
-- one list is longer than the other, then the extra elements
-- are ignored.
-- i.e.
--   map2 f [x1, x2, ..., xn] [y1, y2, ..., yn, yn+1]
--        returns [f x1 y1, f x2 y2, ..., f xn yn]
--
-- NOTE: map2 is called zipWith in the Prelude

map2 :: (a -> b -> c) -> [a] -> [b] -> [c]
map2 f [] _          = []
map2 f _ []          = []
map2 f (x:xs) (y:ys) = f x y : map2 f xs ys 

tmap2 :: Test
tmap2 = "map2" ~: TestList
   [ map2 (+) [1,2,3] [4,5,6] ~?= [5,7,9],
     map2 (*) [1,2,3] [4,5] ~?= [4,10] ]

-- mapMaybe

-- Map a partial function over all the elements of the list
-- for example:
--    mapMaybe root [0.0, -1.0, 4.0] == [0.0,2.0]

root :: Double -> Maybe Double
root d = if d < 0.0 then Nothing else Just $ sqrt d

-- catMaybes is defined in module Data.Maybe
catMaybes :: [Maybe a] -> [a]
catMaybes ls = [x | Just x <- ls]

mapMaybe :: (a -> Maybe b) -> [a] -> [b]
mapMaybe f = catMaybes . map f

tmapMaybe :: Test
tmapMaybe = "mapMaybe" ~: TestList
   [ mapMaybe root [0.0, -1.0, 4.0] ~?= [0.0,2.0],
     mapMaybe root [-1.0, -1.0] ~?= [] ]
----------------------------------------------------------------------

testFoldr :: Test
testFoldr = TestList [tinvert, tintersperse, tconcat, tstartsWith, tcountSub]

invert :: [(a,b)] -> [(b,a)]
invert = map (\(x,y) -> (y,x)) 

tinvert :: Test
tinvert = "invert" ~: TestList
   [ invert ([] :: [(Int,Int)]) ~?= [],
     invert [(1,2),(3,4)] ~?= [(2,1),(4,3)] ]

intersperse ::  a -> [a] -> [a]
prependToAll sep = foldr (\x xs -> sep:x:xs) []
intersperse sep []     = []
intersperse sep [x]    = [x]
intersperse sep (x:xs) = (x : prependToAll sep xs)

tintersperse :: Test
tintersperse = "intersperse" ~: TestList
   [ intersperse ',' ([]::[Char]) ~?= [],
     intersperse ',' "a" ~?= "a",
     intersperse ',' "abcd" ~?= "a,b,c,d" ]

-- concat

concat :: [[a]] -> [a]
concat = foldr (++) []

tconcat :: Test
tconcat = "concat" ~: TestList
   [ concat ([]::[[Int]]) ~?= [],
     concat ([[]]::[[Int]]) ~?= [],
     concat [[1,2],[1,2,3],[2,2]] ~?= [1,2,1,2,3,2,2] ]

-- startsWith using foldr
-- how this works: (foldr step done xs) returns a function that consumes ys
-- so we go down the xs list building up a nested composition of functions
-- that will each be applied to the corresponding part of ys.
startsWith :: String -> String -> Bool
startsWith = foldr step done
   where done ys = True
         step x _  []     = False
         step x fn (y:ys) = (x == y) && (fn ys) 


tstartsWith = "tstartsWith" ~: TestList
   [ startsWith "" "abc" ~?= True,
     startsWith "a" "" ~?= False,
     startsWith "aa" "aabcaa"~?= True,
     startsWith "aa" "abaa" ~?= False ]

-- countSub: counts the number of occurrences of a non empty
-- subslistg s in a list l; returns 0 if s is an empty list    
para :: (a -> [a] -> b -> b) -> b -> [a] -> b
para f z []     = z
para f z (x:xs) = f x xs (para f z xs) 

-- 
countSub  :: String -> String -> Int
countSub [] _ = 0
countSub s l = para f 0 l 
   where f x xs n
           | startsWith s (x:xs) = n+1
           | otherwise           = n
      
tcountSub = "countSub" ~: TestList
   [ countSub "aa" "aaa" ~?= 2,
     countSub "aa" "abaabaaa" ~?= 3,
     countSub "" "" ~?= 0,
     countSub "" "aa" ~?= 0 ]

----------------------------------------------------------------------

testTree :: Test
testTree = TestList [ tappendTree, tinvertTree, ttakeWhileTree, tallTree, tmap2Tree,
                      tinfixOrder1, tinfixOrder2 ]

-- | a basic tree data structure
data Tree a = Empty | Branch a (Tree a) (Tree a) deriving (Show, Eq)

mapTree :: (a -> b) -> Tree a -> Tree b
mapTree f Empty = Empty
mapTree f (Branch x t1 t2) = Branch (f x) (mapTree f t1) (mapTree f t2)

foldTree :: (a -> b -> b -> b) -> b -> Tree a -> b
foldTree _ e Empty     = e
foldTree f e (Branch a n1 n2) = f a (foldTree f e n1) (foldTree f e n2)

-- The appendTree function takes two trees and replaces all of the 'Empty'
-- constructors in the first with the second tree.  For example:
--     appendTree (Branch 'a' Empty Empty) (Branch 'b' Empty Empty) returns
--        Branch 'a' (Branch 'b' Empty Empty) (Branch 'b' Empty Empty)

appendTree :: Tree a -> Tree a -> Tree a
appendTree t1 t2 = foldTree Branch t2 t1  

tappendTree :: Test
tappendTree = "appendTree" ~: TestList
   [ appendTree (Branch 'a' Empty Empty) (Branch 'b' Empty Empty) ~?= Branch 'a' (Branch 'b' Empty Empty) (Branch 'b' Empty Empty),
     appendTree  (Branch 'a' Empty Empty) Empty ~?=  (Branch 'a' Empty Empty),
     appendTree  (Empty:: Tree Char) Empty ~?=  Empty ]
     
-- The invertTree function takes a tree of pairs and returns a new tree
-- with each pair reversed.  For example:
--     invertTree (Branch ("a",1) Empty Empty) returns Branch (1,"a") Empty Empty

invertTree :: Tree (a,b) -> Tree (b,a)
invertTree = mapTree (\(x,y) -> (y,x))

tinvertTree :: Test
tinvertTree = "invertTree" ~: TestList
   [ invertTree (Branch ("a",1) Empty Empty) ~?= Branch (1,"a") Empty Empty,
     invertTree (Empty :: Tree (String,Int)) ~?= Empty ]

-- takeWhileTree, applied to a predicate p and a tree t,
-- returns the largest prefix tree of t  (possibly empty)
-- where all elements satisfy p.
-- For example, given the following tree

tree1 :: Tree Int
tree1 = Branch 1 (Branch 2 Empty Empty) (Branch 3 Empty Empty)
tree2 = Branch 2 (Branch 2 Empty Empty) (Branch 4 Empty Empty)

--     takeWhileTree (< 3) tree1  returns Branch 1 (Branch 2 Empty Empty) Empty
--     takeWhileTree (< 9) tree1  returns tree1
--     takeWhileTree (< 0) tree1  returns Empty

takeWhileTree :: (a -> Bool) -> Tree a -> Tree a
takeWhileTree p = foldTree f Empty
   where f x t1 t2 
           | p x       = Branch x t1 t2
           | otherwise = Empty

ttakeWhileTree :: Test
ttakeWhileTree = "takeWhileTree" ~: TestList
   [ takeWhileTree (< 3) tree1 ~?= Branch 1 (Branch 2 Empty Empty) Empty,
     takeWhileTree (< 9) tree1 ~?= tree1,
     takeWhileTree (< 0) tree1 ~?= Empty ]

-- allTree pred tree returns False if any element of tree
-- fails to satisfy pred and True otherwise.
-- for example:
--    allTree odd tree1 returns False

allTree :: (a -> Bool) -> Tree a -> Bool
allTree p = foldTree (\x b1 b2 -> p x && b1 && b2) True

tallTree :: Test
tallTree = "allTree" ~: TestList
   [  allTree odd tree1 ~?= False,
      allTree even tree2 ~?= True,
      allTree odd (Empty :: Tree Int) ~?= True ]

-- WARNING: This one is a bit tricky!  (Hint: the value
-- *returned* by foldTree can itself be a function.)

-- map2Tree f xs ys returns the tree obtained by applying f to
-- to each pair of corresponding elements of xs and ys. If
-- one branch is longer than the other, then the extra elements
-- are ignored.
-- for example:
--    map2Tree (+) (Branch 1 Empty (Branch 2 Empty Empty)) (Branch 3 Empty Empty)
--        should return (Branch 4 Empty Empty)

map2Tree :: (a -> b -> c) -> Tree a -> Tree b -> Tree c
map2Tree f = foldTree step done
   where done t = Empty
         step x _  _  Empty            = Empty
         step x fl fr (Branch y t1 t2) = Branch (f x y) (fl t1) (fr t2) 

tmap2Tree :: Test
tmap2Tree = "map2Tree" ~: TestList
   [ map2Tree (+) (Branch 1 Empty (Branch 2 Empty Empty)) (Branch 3 Empty Empty) ~?= (Branch 4 Empty Empty),
     map2Tree (+) Empty tree1 ~?= Empty,
     map2Tree (+) tree1    Empty ~?= Empty ]
----------------------------------------------------------------------

testFoldTree :: Test
testFoldTree = TestList [ tinfixOrder1, tinfixOrder2, trevOrder, tfoldrTree', tfoldlTree' ]

infixOrder :: Tree a -> [a]
infixOrder Empty = []
infixOrder (Branch x l r) = infixOrder l ++ [x] ++ infixOrder r

exTree :: Tree Int
exTree = Branch 5 (Branch 2 (Branch 1 Empty Empty) (Branch 4 Empty Empty))
                  (Branch 9 Empty (Branch 7 Empty Empty))

testInfixOrder = "infixOrder" ~: infixOrder exTree ~?= [1,2,4,5,9,7]

infixOrder1 :: Tree a -> [a]
infixOrder1 = foldTree (\x xs ys -> xs ++ [x] ++ ys) []

tinfixOrder1 = "infixOrder2" ~: infixOrder1 exTree ~?= [1,2,4,5,9,7]

foldrTree :: (a -> b -> b) -> b -> Tree a -> b
foldrTree _ e Empty = e
foldrTree f e (Branch k l r) = foldrTree f (f k (foldrTree f e r)) l

infixOrder2 :: Tree a -> [a]
infixOrder2 = foldrTree (:) []

tinfixOrder2 = "infixOrder2" ~: infixOrder2 exTree ~?= [1,2,4,5,9,7]

foldlTree :: (b -> a -> b) -> b -> Tree a -> b
foldlTree _ e Empty = e
foldlTree f e (Branch k l r) = foldlTree f (f (foldlTree f e l) k) r

revOrder :: Tree a -> [a]
revOrder = foldlTree (flip (:)) []
trevOrder = "revOrder" ~: revOrder exTree ~?= [7,9, 5, 4, 2, 1]

foldrTree' :: (a -> b -> b) -> b ->  Tree a -> b
foldrTree' f e t = foldTree step done t e
   where done e = e
         step x fl fr = \e -> let e' = f x (fr e) in fl e'

tfoldrTree' :: Test
tfoldrTree' = TestList ["foldrTree'" ~: foldrTree' (+) 0 tree1 ~?= 6 ]

foldlTree' :: (b -> a -> b) -> b -> Tree a -> b
foldlTree' f e t = foldTree step done t e
   where done e = e
         step x fl fr = \e -> let e' = f (fl e) x in fr e'

revOrder' = foldlTree' (flip (:)) []

tfoldlTree' :: Test
tfoldlTree' = TestList ["foldlTree'" ~: foldlTree (+) 0 tree1 ~?= 6 ]

----------------------------------------------------------------------


changeTag :: ElementName -> SimpleXML -> SimpleXML
changeTag tag (Element _ body) = (Element tag body)
changeTag _   e = e

addEndTag :: ElementName -> SimpleXML -> [SimpleXML]
addEndTag etag e = e : [Element etag []]

bodyWithHTMLTitle :: ElementName -> [SimpleXML] -> [SimpleXML]
bodyWithHTMLTitle tag (etitle:body) = changeTag tag etitle : concatMap play2HTML body
bodyWithHTMLTitle _   [] = []

play2HTML :: SimpleXML -> [SimpleXML]
play2HTML (Element name body) =
   case name of
      "PLAY"     -> bodyWithHTMLTitle "h1" body
      "PERSONAE" -> bodyWithHTMLTitle "h2" (Element "TITLE" [PCDATA "Dramatis Personae"] : body)
      "PERSONA"  -> addEndTag "br" (head body)
      "ACT"      -> bodyWithHTMLTitle "h2" body
      "SCENE"    -> bodyWithHTMLTitle "h3" body
      "SPEECH"   -> concatMap play2HTML body
      "SPEAKER"  -> addEndTag "br" (Element "b" body) 
      "LINE"     -> addEndTag "br" (head body) 
      _         -> []
       
play2HTML (PCDATA s)          = [PCDATA s]

formatPlay :: SimpleXML -> SimpleXML
formatPlay play = Element "html" [Element "body" (play2HTML play)]

---

firstDiff :: Eq a => [a] -> [a] -> Maybe ([a],[a])
firstDiff [] [] = Nothing
firstDiff (c:cs) (d:ds)
    | c==d = firstDiff cs ds
    | otherwise = Just (c:cs, d:ds)
firstDiff cs ds = Just (cs,ds)

-- | Test the two files character by character, to determine whether
-- they match.
testResults :: String -> String -> IO ()
testResults file1 file2 = do
  f1 <- readFile file1
  f2 <- readFile file2
  case firstDiff f1 f2 of
    Nothing -> return ()
    Just (cs,ds) -> assertFailure msg where
      msg  = "Results differ: '" ++ take 20 cs ++
            "' vs '" ++ take 20 ds

testXML :: Test
testXML = TestCase $ do
  writeFile "dream.html" (xml2string (formatPlay play))
  testResults "dream.html" "sample.html"

